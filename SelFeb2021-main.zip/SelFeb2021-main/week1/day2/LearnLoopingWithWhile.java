package week1.day2;

public class LearnLoopingWithWhile {

	public static void main(String[] args) {

		int input = 5;
		
		/*
		 * do { System.out.println(input); }while(input > 10);
		 */
		
		
		  while(input < 10) { 
			  System.out.println(input); 
			  // input++; }
		  }
		 
		

	}

}
