package week6.day1;

public class EmployeeInfo {

	public static void main(String[] args) {
		Employees.staticMethod();

	}

}
